#include "ArrayList.h"

struct list_s{
	place_t* arr;
	int length;
};

list_t list_new(int capacity){
	list_t list = malloc(sizeof(struct list_s));
	list->arr = malloc(capacity*sizeof(list_t));
	list->length = 0;
}

void list_free(list_t self){
	free(self->arr);
	free(self);
}

void list_add(list_t self, place_t data){
	self->arr[self->length++] = data;
}

int list_addByIndex(list_t self, place_t data, int index){
	if (index > self->length || index < 0) return 0;
	for (int i = self->length; i > index; i--){
		self->arr[i] = self->arr[i - 1];
	}
	self->arr[index] = data;
	self->length++;
	return 1;
}

int list_setByIndex(list_t self, place_t data, int index){
	if (index > self->length || index < 0) return 0;
	self->arr[index] = data;
	return 1;
}

place_t list_get(list_t self, int index){
	return self->arr[index];
}

place_t list_delete(list_t self, int index){
	if (index >= self->length || index < 0) return NULL;
	place_t res = self->arr[index];
	for (int i = index; i < self->length - 1; i++){
		self->arr[i] = self->arr[i + 1];
	}
	self->length--;
	return res;
}

int list_length(list_t self){
	return self->length;
}

void list_print(list_t self){
	//TODO
}

